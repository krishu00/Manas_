import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  TextInput,
  Image,
  SafeAreaView,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { apiMiddleware } from '../../src/apiMiddleware/apiMiddleware';
import logoImage from '../../src/logos/logo-HD.png';
import Popup from '../Popup/Popup';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import * as Keychain from 'react-native-keychain';
import AsyncStorage from '@react-native-async-storage/async-storage';

const LoginScreen = ({ navigation, onLoginSuccess, fcmToken }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [controller, setController] = useState(null);

  // Popup state
  const [popupVisible, setPopupVisible] = useState(false);
  const [popupTitle, setPopupTitle] = useState('');
  const [popupMessage, setPopupMessage] = useState('');

  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false); // ✅ new state

  const showPopup = (title, message) => {
    setPopupTitle(title);
    setPopupMessage(message);
    setPopupVisible(true);
  };

  // // 👇 Load saved credentials when component mounts
  // useEffect(() => {
  //   const loadCredentials = async () => {
  //     try {
  //       const credentials = await Keychain.getGenericPassword();
  //       if (credentials) {
  //         setEmail(credentials.username);
  //         setPassword(credentials.password);
  //         setRememberMe(true); // pre-check the box if data exists
  //       }
  //     } catch (err) {
  //       console.log('Keychain error', err);
  //     }
  //   };
  //   loadCredentials();
  // }, []);
  // 👇 Load saved accounts on mount
  useEffect(() => {
    const loadCredentials = async () => {
      try {
        const savedEmails = JSON.parse(
          (await AsyncStorage.getItem('savedAccounts')) || '[]',
        );
        if (savedEmails.length > 0) {
          // Load the last used account by default
          const lastEmail = savedEmails[savedEmails.length - 1];
          const credentials = await Keychain.getGenericPassword({
            service: `app-${lastEmail}`,
          });

          if (credentials) {
            setEmail(credentials.username);
            setPassword(credentials.password);
            setRememberMe(true);
          }
        }
      } catch (err) {
        console.log('Keychain error', err);
      }
    };
    loadCredentials();
  }, []);
  const handleLogin = async () => {
    const abortController = new AbortController();
    setController(abortController);
    console.log("apiMiddleware", apiMiddleware)
    try {
      const response = await apiMiddleware.post(
        '/login',
        {
          email: email.trim(),
          password: password.trim(),
          platform: 'android',
          fcmToken: fcmToken,
        },
        {
          headers: { 'Content-Type': 'application/json' },
          signal: abortController.signal,
        },
      );

      if (response?.data?.success) {
        const { employee, firstTimeLogin } = response.data;
        const { token } = employee;
        if (firstTimeLogin) {
          navigation.replace('FirstTimeLogin');
          return;
        }
        console.log('response?.data login  ', response?.data);

        if (employee && employee.employee_id && employee.company_code) {
          await AsyncStorage.setItem('employee_id', employee.employee_id);

          await AsyncStorage.setItem(
            'company_Code',
            employee.company_code.toString(),
          );

          await AsyncStorage.setItem('loginTime', Date.now().toString());

          if (fcmToken) {
            await AsyncStorage.setItem('fcmToken', fcmToken);
          }

          if (token) {
            await AsyncStorage.setItem('userToken', token);
          }

          // ✅ Save credentials securely if Remember Me checked
          if (rememberMe) {
            // Save this account in Keychain with unique service name
            await Keychain.setGenericPassword(email.trim(), password.trim(), {
              service: `app-${email.trim()}`,
            });

            let savedEmails = JSON.parse(
              (await AsyncStorage.getItem('savedAccounts')) || '[]',
            );

            if (!savedEmails.includes(email.trim())) {
              savedEmails.push(email.trim());

              await AsyncStorage.setItem(
                'savedAccounts',
                JSON.stringify(savedEmails),
              );
            }
          }
          console.log('ASYNC CHECK', await AsyncStorage.getItem('employee_id'));

          console.log(
            'ASYNC CHECK',
            await AsyncStorage.getItem('company_Code'),
          );
          onLoginSuccess(token);


          console.log(
            '========== LOGIN STORAGE CHECK =========='
          );

          console.log(
            'userToken:',
            await AsyncStorage.getItem('userToken')
          );

          console.log(
            'employee_id:',
            await AsyncStorage.getItem('employee_id')
          );

          console.log(
            'company_Code:',
            await AsyncStorage.getItem('company_Code')
          );

          console.log(
            'loginTime:',
            await AsyncStorage.getItem('loginTime')
          );

          console.log(
            '=========================================='
          );
        } else {
          showPopup('Login Failed', 'Employee data missing in response.');
        }
      } else {
        showPopup(
          'Login Failed',
          response?.data?.message || 'Invalid credentials. Please try again.',
        );
      }
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('Login request aborted');
      } else {
        console.error('Login error:', error);
        showPopup(
          'Error',
          error.response?.data?.message ||
          'An error occurred during login. Please try again.',
        );
      }
    }
  };

  const handleForgotPassword = async () => {
    if (!email) {
      showPopup(
        'Missing Info',
        'Please enter your email or mobile number first.',
      );
      return;
    }

    try {
      const response = await apiMiddleware.post(
        '/forgot_password',
        { email: email.trim() },
        { headers: { 'Content-Type': 'application/json' } },
      );

      if (response?.data?.success) {
        showPopup(
          'Success',
          'Password reset link has been sent to your email.',
        );
      } else {
        showPopup(
          'Error',
          response?.data?.message || 'Failed to send reset link.',
        );
      }
    } catch (error) {
      console.error('Forgot password error:', error);
      showPopup(
        'Error',
        error.response?.data?.message ||
        'Something went wrong. Please try again.',
      );
    }
  };

  useEffect(() => {
    return () => {
      if (controller) controller.abort();
    };
  }, [controller]);

  return (
    <LinearGradient
      colors={['#F3F4F3', '#E5EEE6', '#DEECDD']}
      style={styles.container}
    >
      {/* <AppHeader
        isBlogHeader
        backTarget="BlogFeed"
        showAuthButton={false}
      /> */}
      <SafeAreaView style={styles.content}>
        <TouchableOpacity
          accessibilityLabel="Go back to feed"
          onPress={() => navigation.goBack()}
          style={styles.backButton}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
        >
          <FontAwesome name="arrow-left" size={22} color="#6a9689" />
        </TouchableOpacity>

        <Image source={logoImage} style={styles.logo} />
        <View style={styles.titleContainer}>
          <Text style={styles.subTitleText}>Welcome To Manas</Text>
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            placeholder="Email or Mobile number"
            style={styles.textInput}
            placeholderTextColor="#AFAFB0"
            value={email}
            onChangeText={text => setEmail(text.trim())}
          />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            placeholder="Enter Your Password"
            style={styles.textInputWithIcon}
            placeholderTextColor="#AFAFB0"
            secureTextEntry={!showPassword}
            value={password}
            onChangeText={text => setPassword(text.trim())}
          />
          <TouchableOpacity
            onPress={() => setShowPassword(!showPassword)}
            style={styles.eyeIcon}
          >
            <FontAwesome
              name={showPassword ? 'eye' : 'eye-slash'}
              size={20}
              color="#6a9689"
            />
          </TouchableOpacity>
        </View>

        {/* ✅ Remember Me */}
        <View style={styles.rememberMeContainer}>
          <TouchableOpacity
            onPress={() => setRememberMe(!rememberMe)}
            style={styles.checkbox}
          >
            {rememberMe && <Text style={styles.checkmark}>✓</Text>}
          </TouchableOpacity>
          <Text style={styles.rememberMeText}>Remember Me</Text>
        </View>

        <View style={styles.forgotPasswordContainer}>
          <TouchableOpacity onPress={handleForgotPassword}>
            <Text style={styles.forgotPasswordText}>Forgot Password ?</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.signInButton} onPress={handleLogin}>
          <Text style={styles.signInButtonText}>Login</Text>
        </TouchableOpacity>

        <Text style={styles.bottomText}>@powered by M2R Technomations</Text>

        {popupVisible && (
          <Popup
            title={popupTitle}
            message={popupMessage}
            onClose={() => setPopupVisible(false)}
          />
        )}
      </SafeAreaView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: {
    flex: 1,
    paddingHorizontal: 28,
    paddingTop: 32,
    paddingBottom: 16,
  },
  backButton: {
    position: 'absolute',
    top: 55,
    left: 20,
    zIndex: 10,

    width: 50,
    height: 50,

    borderRadius: 25,

    justifyContent: 'center',
    alignItems: 'center',

    backgroundColor: 'rgba(129, 186, 165, 0.15)',
  },
  logo: {
    width: 250,
    height: 150,
    resizeMode: 'contain',
    alignSelf: 'center',
    marginBottom: 20,
  },
  titleContainer: { alignItems: 'center', marginVertical: 8 },
  subTitleText: { fontSize: 32, fontWeight: '700', color: '#6a9689' },
  inputContainer: {
    marginVertical: 16,
    marginHorizontal: 14,
  },
  textInput: {
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    color: '#000',
    borderWidth: 1,
    borderColor: 'rgba(106, 150, 137, 0.12)',
  },
  textInputWithIcon: {
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    color: '#000',
    paddingRight: 45,
    borderWidth: 1,
    borderColor: 'rgba(106, 150, 137, 0.12)',
  },
  eyeIcon: { position: 'absolute', right: 16, top: 18 },
  forgotPasswordContainer: {
    alignItems: 'flex-end',
    marginHorizontal: 14,
    marginBottom: 8,
  },
  forgotPasswordText: { color: '#0066B2', fontWeight: '600' },
  signInButton: {
    padding: 16,
    backgroundColor: '#81BAA5',
    borderRadius: 8,
    alignItems: 'center',
    marginVertical: 32,
    width: '50%',
    alignSelf: 'center',
  },
  signInButtonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  bottomText: { textAlign: 'center', marginTop: 'auto', color: '#AFAFB0' },
  rememberMeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginBottom: 16,
    marginLeft: 10,
    marginRight: 10,
    paddingLeft: 10,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#6a9689',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 8,
  },
  checkmark: { color: '#6a9689', fontWeight: 'bold' },
  rememberMeText: { color: '#333' },
});

export default LoginScreen;
