import React, {
  useEffect,
  useState,
  useCallback,
} from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
  ScrollView,
} from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';

import BlogImage from '../../common/BlogImage';

import {
  COLORS,
  SPACING,
  FONT,
} from '../../../src/utils/theme';

import {
  createBlog,
} from '../../../src/api/blogApi';

import Popup from '../../Popup/Popup';


// =====================================================
// SCREEN
// =====================================================

const CreateBlogScreen = ({
  navigation,
}) => {

  const [title, setTitle] =
    useState('');

  const [description, setDescription] =
    useState('');

  const [imageUrl, setImageUrl] =
    useState('');

  const [submitting, setSubmitting] =
    useState(false);

  const [isLoggedIn, setIsLoggedIn] =
    useState(false);

  const [checkingAuth, setCheckingAuth] =
    useState(true);


  // ===================================================
  // POPUP
  // ===================================================

  const [popup, setPopup] =
    useState({
      visible: false,
      title: '',
      message: '',
    });


  // ===================================================
  // SHOW POPUP
  // ===================================================

  const showPopup =
    useCallback(
      (
        popupTitle,
        popupMessage,
      ) => {

        console.log(
          '🔔 SHOW POPUP:',
          popupTitle,
          popupMessage,
        );

        setPopup({
          visible: true,
          title:
            popupTitle ||
            'Message',
          message:
            popupMessage ||
            '',
        });

      },
      [],
    );


  // ===================================================
  // CLOSE POPUP
  // ===================================================

  const closePopup =
    useCallback(
      () => {

        setPopup({
          visible: false,
          title: '',
          message: '',
        });

      },
      [],
    );


  // =====================================================
  // CHECK LOGIN
  // =====================================================

  useEffect(() => {

    const checkAuth =
      async () => {

        try {

          const token =
            await AsyncStorage.getItem(
              'userToken',
            );

          setIsLoggedIn(
            !!token,
          );

        } catch (error) {

          console.error(
            'Create Blog auth check error:',
            error,
          );

          setIsLoggedIn(false);

        } finally {

          setCheckingAuth(false);

        }

      };


    checkAuth();

  }, []);


  // =====================================================
  // GO TO LOGIN
  // =====================================================

  const goToLogin = () => {

    navigation.navigate(
      'Login',
    );

  };


  // =====================================================
  // PUBLISH BLOG
  // =====================================================

  const handlePublish =
    async () => {

      // =================================================
      // AUTH CHECK
      // =================================================

      const token =
        await AsyncStorage.getItem(
          'userToken',
        );


      if (!token) {

        showPopup(
          'Login Required',
          'Please login to create a blog.',
        );

        return;

      }


      // =================================================
      // VALIDATION
      // =================================================

      if (!title.trim()) {

        showPopup(
          'Title Required',
          'Please enter a blog title.',
        );

        return;

      }


      if (!description.trim()) {

        showPopup(
          'Description Required',
          'Please write something for your blog.',
        );

        return;

      }


      // =================================================
      // START LOADING
      // =================================================

      setSubmitting(true);


      try {

        // ===============================================
        // API CALL
        // ===============================================

        const response =
          await createBlog({

            title:
              title.trim(),

            description:
              description.trim(),

            image:
              imageUrl.trim() ||
              null,

          });


        console.log(
          '✅ Blog created successfully:',
          response,
        );


        // ===============================================
        // SUCCESS
        // ===============================================

        showPopup(
          'Success',
          response?.message ||
            'Your blog has been published successfully.',
        );


        // ===============================================
        // CLEAR FORM
        // ===============================================

        setTitle('');
        setDescription('');
        setImageUrl('');


        // ===============================================
        // GO BACK TO BLOG FEED
        // ===============================================

        /*
         * Popup is displayed first.
         *
         * Your existing Popup handles
         * its own auto-close behavior.
         *
         * We wait for the popup to finish
         * before navigating.
         */

        setTimeout(() => {

          closePopup();

          navigation.navigate(
            'BlogFeed',
            {
              refreshKey:
                Date.now(),
            },
          );

        }, 2000);


      } catch (error) {

        console.log(
          '❌ Create Blog Error:',
          error?.response?.data ||
            error?.message ||
            error,
        );


        // ===============================================
        // AUTH ERROR
        // ===============================================

        if (
          error?.response?.status === 401
        ) {

          showPopup(
            'Login Required',
            'Your session has expired. Please login again.',
          );


          setTimeout(() => {

            closePopup();

            goToLogin();

          }, 2000);


          return;

        }


        // ===============================================
        // SERVER / API ERROR
        // ===============================================

        showPopup(
          'Could not publish',
          error?.response?.data?.message ||
            'Something went wrong while publishing the blog.',
        );

      } finally {

        setSubmitting(false);

      }

    };


  // =====================================================
  // AUTH CHECK LOADING
  // =====================================================

  if (checkingAuth) {

    return (

      <SafeAreaView
        style={
          styles.safeArea
        }
      >

        <View
          style={
            styles.loadingContainer
          }
        >

          <ActivityIndicator
            size="large"
            color={
              COLORS.primary
            }
          />

        </View>

      </SafeAreaView>

    );

  }


  // =====================================================
  // SCREEN
  // =====================================================

  return (

    <SafeAreaView
      style={
        styles.safeArea
      }
    >

      {/* ================================================= */}
      {/* TOP BAR */}
      {/* ================================================= */}

      <View
        style={
          styles.topBar
        }
      >

        <TouchableOpacity
          onPress={() =>
            navigation.goBack()
          }
          hitSlop={{
            top: 10,
            bottom: 10,
            left: 10,
            right: 10,
          }}
        >

          <Text
            style={
              styles.backText
            }
          >
            ← Create Blog
          </Text>

        </TouchableOpacity>


        <TouchableOpacity
          onPress={
            handlePublish
          }
          disabled={
            submitting ||
            !title.trim() ||
            !description.trim()
          }
        >

          {submitting ? (

            <ActivityIndicator
              size="small"
              color={
                COLORS.primaryLight
              }
            />

          ) : (

            <Text
              style={[
                styles.postText,

                (
                  !title.trim() ||
                  !description.trim()
                ) &&
                  styles.postTextDisabled,
              ]}
            >
              Post
            </Text>

          )}

        </TouchableOpacity>

      </View>


      {/* ================================================= */}
      {/* CONTENT */}
      {/* ================================================= */}

      <ScrollView
        contentContainerStyle={
          styles.content
        }
      >

        {/* TITLE */}

        <Text
          style={
            styles.label
          }
        >
          Title
        </Text>


        <TextInput
          style={
            styles.input
          }
          placeholder="Enter blog title..."
          placeholderTextColor={
            COLORS.textMuted
          }
          value={
            title
          }
          onChangeText={
            setTitle
          }
          maxLength={
            200
          }
        />


        {/* DESCRIPTION */}

        <Text
          style={
            styles.label
          }
        >
          Description
        </Text>


        <TextInput
          style={[
            styles.input,
            styles.textArea,
          ]}
          placeholder="Write your blog..."
          placeholderTextColor={
            COLORS.textMuted
          }
          value={
            description
          }
          onChangeText={
            setDescription
          }
          multiline
          numberOfLines={
            8
          }
          textAlignVertical="top"
          maxLength={
            10000
          }
        />


        {/* IMAGE */}

        <Text
          style={
            styles.label
          }
        >
          Image URL (optional)
        </Text>


        <TextInput
          style={
            styles.input
          }
          placeholder="https://..."
          placeholderTextColor={
            COLORS.textMuted
          }
          value={
            imageUrl
          }
          onChangeText={
            setImageUrl
          }
          autoCapitalize="none"
          autoCorrect={false}
        />


        {/* IMAGE PREVIEW */}

        {!!imageUrl.trim() && (

          <BlogImage
            uri={
              imageUrl.trim()
            }
            style={
              styles.preview
            }
          />

        )}


        {/* PUBLISH */}

        <TouchableOpacity
          style={[
            styles.publishButton,

            (
              !title.trim() ||
              !description.trim() ||
              submitting
            ) &&
              styles.publishButtonDisabled,
          ]}
          onPress={
            handlePublish
          }
          disabled={
            !title.trim() ||
            !description.trim() ||
            submitting
          }
        >

          {submitting ? (

            <ActivityIndicator
              color="#ffffff"
            />

          ) : (

            <Text
              style={
                styles.publishButtonText
              }
            >
              Publish Blog
            </Text>

          )}

        </TouchableOpacity>

      </ScrollView>


      {/* ================================================= */}
      {/* POPUP */}
      {/* ================================================= */}

      {popup.visible && (

        <Popup
          title={
            popup.title
          }
          message={
            popup.message
          }
          onClose={
            closePopup
          }
        />

      )}

    </SafeAreaView>

  );

};


// =====================================================
// STYLES
// =====================================================

const styles =
  StyleSheet.create({

    safeArea: {
      flex: 1,
      backgroundColor:
        COLORS.surface,
    },


    loadingContainer: {
      flex: 1,
      alignItems:
        'center',
      justifyContent:
        'center',
    },


    topBar: {
      flexDirection:
        'row',

      justifyContent:
        'space-between',

      alignItems:
        'center',

      paddingHorizontal:
        SPACING.lg,

      paddingVertical:
        SPACING.md,

      borderBottomWidth:
        1,

      borderBottomColor:
        COLORS.border,
    },


    backText: {
      fontSize:
        FONT.md,

      fontWeight:
        '700',

      color:
        COLORS.text,
    },


    postText: {
      fontSize:
        FONT.md,

      fontWeight:
        '700',

      color:
        COLORS.primaryLight,
    },


    postTextDisabled: {
      color:
        COLORS.textMuted,
    },


    content: {
      padding:
        SPACING.lg,

      paddingBottom:
        SPACING.xxl,
    },


    label: {
      fontSize:
        FONT.sm,

      fontWeight:
        '700',

      color:
        COLORS.text,

      marginBottom:
        SPACING.xs,

      marginTop:
        SPACING.lg,
    },


    input: {
      borderWidth:
        1,

      borderColor:
        COLORS.border,

      borderRadius:
        8,

      paddingHorizontal:
        SPACING.md,

      paddingVertical:
        SPACING.sm,

      fontSize:
        FONT.md,

      color:
        COLORS.text,
    },


    textArea: {
      height:
        160,
    },


    preview: {
      width:
        '100%',

      height:
        160,

      borderRadius:
        8,

      marginTop:
        SPACING.md,
    },


    publishButton: {
      marginTop:
        SPACING.xxl,

      backgroundColor:
        COLORS.primary,

      borderRadius:
        10,

      paddingVertical:
        SPACING.md,

      alignItems:
        'center',
    },


    publishButtonDisabled: {
      backgroundColor:
        COLORS.border,
    },


    publishButtonText: {
      color:
        '#ffffff',

      fontWeight:
        '700',

      fontSize:
        FONT.md,
    },

  });


export default CreateBlogScreen;