/**
 * @format
 */

import React, { useEffect, useState, useCallback } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ActivityIndicator, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Dashboard from './components/Dashboard';
import LoginScreen from './components/Login/LoginScreen';
import FirstTimeLogin from './components/Login/FirstTimeLogin';
import Popup from './components/Popup/Popup';
import BlogFeedScreen from './components/Screens/Blog/BlogFeedScreen';
import CreateBlogScreen from './components/Screens/Blog/CreateBlogScreen';
import BlogDetailScreen from './components/Screens/Blog/BlogDetailScreen';

// 👇 TEMPORARILY DISABLED FIREBASE IMPORTS 👇
import { requestUserPermission, getFCMToken } from './components/FCMService/FCMService';
import { initFCMListeners } from './src/utils/NotificationService';
import { navigationRef } from './src/utils/NavigationService';

const Stack = createNativeStackNavigator();

// Auto-logout settings
const LOGOUT_HOURS = 36;
const LOGOUT_MILLISECONDS = LOGOUT_HOURS * 60 * 60 * 1000;

const AppMain = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loginLoading, setLoginLoading] = useState(false);

  const [popupVisible, setPopupVisible] = useState(false);
  const [popupTitle, setPopupTitle] = useState('');
  const [popupMessage, setPopupMessage] = useState('');

  const [fcmToken, setFcmToken] = useState('');

  // Show popup helper
  const showPopup = useCallback((title, message) => {
    setPopupTitle(title);
    setPopupMessage(message);
    setPopupVisible(true);
  }, []);

  // ======= Authentication check =======
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const token = await AsyncStorage.getItem('userToken');
        const loginTime = await AsyncStorage.getItem('loginTime');

        if (token && loginTime) {
          const now = Date.now();
          const diff = now - parseInt(loginTime, 10);

          if (diff > LOGOUT_MILLISECONDS) {
            await handleLogout();
            showPopup('Session expired', 'You have been logged out due to inactivity.');
          } else {
            setIsAuthenticated(true);
          }
        }
      } catch (error) {
        console.error('Error checking auth status:', error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, [showPopup]);



  // 👇 TEMPORARILY DISABLED FIREBASE FCM SETUP 👇
  // useEffect(() => {

  //   const setupFCMToken = async () => {
  //     const enabled = await requestUserPermission();
  //     if (enabled) {
  //       try {
  //         const token = await messaging().getToken();
  //         setFcmToken(token);
  //         console.log('FCM Token:', token);
  //       } catch (error) {
  //         console.error('Error getting FCM token:', error);
  //       }
  //     } else {
  //       console.log('FCM Permission denied');
  //     }
  //   };

  //   setupFCMToken();
  //   const unsubscribe = initFCMListeners(); // handles foreground + background + quit
  //   return () => unsubscribe && unsubscribe();

  //   console.log("Firebase is temporarily disabled. Skipping FCM setup.");
  // }, []);


  useEffect(() => {
    let unsubscribe;

    const setupFCM = async () => {
      try {
        console.log('🔥 Starting FCM setup...');

        const permissionGranted = await requestUserPermission();

        if (!permissionGranted) {
          console.log('❌ FCM permission denied');
          return;
        }

        const token = await getFCMToken();

        if (token) {
          setFcmToken(token);
        }

        unsubscribe = initFCMListeners();

        console.log('✅ FCM setup completed');
      } catch (error) {
        console.error('❌ FCM setup failed:', error);
      }
    };

    setupFCM();

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, []);

  // ======= Auto logout =======
  useEffect(() => {
    let timeout;

    const setupAutoLogout = async () => {
      const loginTime = await AsyncStorage.getItem('loginTime');
      if (!loginTime) return;

      const now = Date.now();
      const remaining = parseInt(loginTime, 10) + LOGOUT_MILLISECONDS - now;

      if (remaining <= 0) {
        await handleLogout();
        showPopup('Session expired', 'You have been logged out due to inactivity.');
      } else {
        timeout = setTimeout(async () => {
          await handleLogout();
          showPopup('Session expired', 'You have been logged out due to inactivity.');
        }, remaining);
      }
    };

    if (isAuthenticated) setupAutoLogout();
    return () => timeout && clearTimeout(timeout);
  }, [isAuthenticated, showPopup]);

  // ======= Login & Logout handlers =======
  const handleLoginSuccess = async token => {
    setLoginLoading(true);

    try {
      const now = Date.now();

      await AsyncStorage.setItem('userToken', token);
      await AsyncStorage.setItem('loginTime', now.toString());

      setIsAuthenticated(true);

      navigationRef.current?.reset({
        index: 0,
        routes: [{ name: 'Dashboard' }],
      });

    } catch (error) {
      console.error('Error saving token:', error);
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.removeItem('userToken');
      await AsyncStorage.removeItem('loginTime');
      setIsAuthenticated(false);
    } catch (error) {
      console.error('Error removing token:', error);
    }
  };

  // ======= Render Loading =======
  const renderLoading = (color = '#0000ff') => (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color={color} />
    </View>
  );

  if (loading) return renderLoading();
  if (loginLoading) return renderLoading('#00503D');

  return (
    <>
      <NavigationContainer ref={navigationRef}>
        <Stack.Navigator
          screenOptions={{ headerShown: false }}
          initialRouteName={isAuthenticated ? 'Dashboard' : 'BlogFeed'}
        >
          <Stack.Screen name="BlogFeed" component={BlogFeedScreen} />
          <Stack.Screen name="BlogDetail" component={BlogDetailScreen} />

          <Stack.Screen name="Login">
            {props => (
              <LoginScreen {...props} fcmToken={fcmToken} onLoginSuccess={handleLoginSuccess} />
            )}
          </Stack.Screen>

          <Stack.Screen name="FirstTimeLogin" component={FirstTimeLogin} />
          <Stack.Screen name="CreateBlog" component={CreateBlogScreen} />

          <Stack.Screen name="Dashboard">
            {props => <Dashboard {...props} onLogoutSuccess={handleLogout} />}
          </Stack.Screen>
        </Stack.Navigator>
      </NavigationContainer>
      {popupVisible && (
        <Popup
          title={popupTitle}
          message={popupMessage}
          onClose={() => setPopupVisible(false)}
        />
      )}
    </>
  );
};

// 💡 EXPORT APPMAIN DIRECTLY AS THE DEFAULT EXPORT SO INDEX.JS CAN WEAVE IT IN CLEANLY
export default AppMain;





